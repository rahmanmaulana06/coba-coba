# -*- coding: utf-8 -*-

from odoo import models, fields, api, _
from odoo.exceptions import ValidationError
from collections import defaultdict


class stock_scrap(models.Model):
    _inherit = 'stock.scrap'
    
#     @api.onchange('product_usage')
#     def onchange_product_usage(self):
#         if self.product_usage == True or self.product_usage == False:
#             location = self.env['stock.location'].search([('name','=','Product Usage')],limit=1)
#             if location:
#                 self.scrap_location_id = location.id

class WasteManager(models.Model):
    _inherit = 'waste.manager'

    # usage_reference = fields.Char('Usage Reference', default=lambda self: _('New'))
    usage_type = fields.Many2one('usage.type.alias', string="Usage Type", required=True)

    # @api.model
    # def create(self, vals):
    #     if vals.get('usage_reference', _('New')) == _('New'):
    #         vals['usage_reference'] = self.env['ir.sequence'].next_by_code('waste.manager') or _('New')
    #         return super(WasteManager, self).create(vals)
    
    @api.multi
    def approved(self):
        # for record in self:
        #     record.state = 'approved'
        #     if record.waste_scrap_ids:
        #         for waste_scrap in record.waste_scrap_ids:
        #             waste_scrap.stock_scrap_id.do_scrap()
        #             waste_scrap.stock_scrap_id.product_usage = True

        # Appove based on minimal approval
        if self.approving_matrix_line_ids:
            for approve_line in self.approving_matrix_line_ids:
                for u in self.user_track_ids:
                    for uid in approve_line.approver:
                        if u.user_id.id == uid.id and self.env.user.id == u.user_id.id:
                            if approve_line.count < approve_line.minimal_approver and not u.is_approve:
                                approve_line.count += 1
                            # count of onece user approve first time
                            if approve_line.count == approve_line.minimal_approver:
                                approve_line.is_approved = True

            # track user that approve BOM
            for user in self.user_track_ids:
                if user.user_id == self.env.user:
                    user.is_approve = True

            min_approving = 0
            total_approve = 0
            for approve_line in self.approving_matrix_line_ids:
                min_approving += approve_line.minimal_approver
                if approve_line.is_approved:
                    total_approve += approve_line.count
            if min_approving == total_approve:
                self.write({'state': 'approved'})
                if self.waste_scrap_ids:
                    for waste_scrap in self.waste_scrap_ids:
                        waste_scrap.stock_scrap_id.do_scrap()
                        if waste_scrap.waste_manager_id.usage_type.is_scrap == True:
                            waste_scrap.stock_scrap_id.product_usage = False
                        else:
                            waste_scrap.stock_scrap_id.product_usage = True
                        data = self.env['account.move.line'].search([('name', '=', waste_scrap.stock_scrap_id.name)])
                        for d in data:
                            d.analytic_account_id = waste_scrap.analytic_acc_id.id or False
                            


class WasteScrap(models.Model):
    _inherit = 'waste.scrap'

    @api.onchange('location_id', 'product_id', 'lot_id')
    def onchange_product_id(self):
        res = super(WasteScrap, self).onchange_product_id()
        for quant in self.env['stock.quant'].search([('product_id', '=', self.product_id.id), ('location_id', '=', self.location_id.id), ('lot_id', '=', self.lot_id.id)]):
            self.product_uom_id = quant.product_uom_id.id
        return res
    
#     @api.model
#     def _default_location(self):
#         product_usage = self.env.context.get('default_product_usage', False)
#         if product_usage == True or product_usage == False:
#             location = self.env['stock.location'].search([('name','=','Product Usage')],limit=1)
#             if location:
#                 return location.id
#         return self.env['stock.location']

class stock_quant(models.Model):
    _inherit = 'stock.quant'

    def _create_account_move_line(self, move, credit_account_id, debit_account_id, journal_id):
        # group quants by cost
        self.ensure_one()
        quant_cost_qty = defaultdict(lambda: 0.0)

        for quant in self:
            quant_cost_qty[quant.cost] += quant.qty

        AccountMove = self.env['account.move']
        analytic_account_id = False
        if move.scrapped == True:

            waste_scrap = self.env['waste.scrap'].search([('lot_id', '=', self.lot_id.id)], limit=1)
            if waste_scrap and self.lot_id:

                if waste_scrap.waste_manager_id.usage_type.account_id:
                    stock_scrap_account_id = waste_scrap.waste_manager_id.usage_type.account_id
                else:
                    stock_scrap_account_id = move.product_id.stock_scrap_account_id or move.product_id.categ_id.stock_scrap_account_id
            else:
                stock_scrap_account_id = move.product_id.stock_scrap_account_id or move.product_id.categ_id.stock_scrap_account_id

            debit_account_id = stock_scrap_account_id.id
        for cost, qty in quant_cost_qty.iteritems():
            move_lines = move._prepare_account_move_line(qty, cost, credit_account_id, debit_account_id)
            if move_lines:
                date = self._context.get('force_period_date', fields.Date.context_today(self))
                new_account_move = AccountMove.create({
                    'journal_id': journal_id,
                    'line_ids': move_lines,
                    'date': date,
                    'ref': move.picking_id.name})

                # be carefull, lot might be empty and interpreted as False, so
                # this will search all non-lotted waste scarp
                if self.lot_id:
                    waste_scrap = self.env['waste.scrap'].search([('lot_id', '=', self.lot_id.id)], limit=1,order="id desc")

                    # if waste_scrap.analytic_acc_id:
                    if waste_scrap.waste_manager_id.usage_type.account_id:
                        expense_account_id = waste_scrap.waste_manager_id.usage_type.account_id
                        for line in new_account_move.line_ids:
                            if line.credit != 0.00:
                                line.write({'account_id': line.product_id.categ_id.property_stock_valuation_account_id.id})
                            if line.debit != 0.00:
                                line.write({'account_id': expense_account_id.id})
                new_account_move.post()