# -*- coding: utf-8 -*-

from odoo import models, fields, api, _

class UsageType(models.Model):
    _name = 'usage.type.alias'

    name = fields.Char("Usage Type")
    account_id = fields.Many2one("account.account",string="Expense Account", required=True)
    is_scrap = fields.Boolean('Is Scrap')