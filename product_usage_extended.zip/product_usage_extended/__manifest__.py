# -*- coding: utf-8 -*-
# Part of Odoo. See LICENSE file for full copyright and licensing details.

{
    'name': 'Product Usage Extended',
    'version': '1.2.5',
    'category': 'Purchase',
    'description': "Product usage or scrap",
    'depends': ['stock','product_usage','scrap_accounting'],
    'data': [
        'views/usage_type_alias.xml',
        'views/purchase_usage_view.xml',
    ],
    'installable': True,
    'application': True,
}
